
import React, { useState } from "react";
import ProfileModal from "./ProfileModal";
import { CgProfile } from "react-icons/cg";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const CandidateApproval = () => {
  const [selectedProfile, setSelectedProfile] = useState(null);
  const [candidates, setCandidates] = useState([
    {
      id: 1,
      name: "Joey Tribbs",
      email: "joeytribbs@gmail.com",
      profile: { /* profile data */ },
      approve: false,
      banPeriod: "5 Months",
    },
  ]);

  const weeklyData = { /* weekly chart data */ };
  const yearlyData = { /* yearly chart data */ };
  const options = { /* chart options */ };

  const handleViewProfile = (profile) => setSelectedProfile(profile);
  const handleCloseModal = () => setSelectedProfile(null);
  const handleToggleApproval = (id) => {
    const updatedCandidates = candidates.map((candidate) =>
      candidate.id === id ? { ...candidate, approve: !candidate.approve } : candidate
    );
    setCandidates(updatedCandidates);
  };

  return (
    <div className="min-h-screen mx-auto max-w-7xl px-4 md:px-8">
      <div className="flex flex-wrap justify-between items-center mb-6">
        <h1 className="text-3xl sm:text-4xl font-bold text-usedColor">Visitor Approval</h1>
        <CgProfile className="text-3xl sm:text-4xl text-usedColor" />
      </div>
      <h2 className="text-2xl sm:text-3xl font-semibold text-usedColor mb-6">Dashboard</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="border rounded-md p-4 bg-white border-black shadow-md">
          <h3 className="text-lg font-bold text-orange-800">Total Signups this Week</h3>
          <Bar data={weeklyData} options={options} />
        </div>
        <div className="border rounded-md p-4 bg-white border-black shadow-md">
          <h3 className="text-lg font-bold text-orange-800">Total Signups this Year</h3>
          <Bar data={yearlyData} options={options} />
        </div>
      </div>

      <table className="mt-8 w-full border-collapse border border-grey-300 text-sm sm:text-base">
        <thead className="bg-orange-200 text-orange-800">
          <tr>
            <th className="p-2 sm:p-4 border border-grey-300">NAME</th>
            <th className="p-2 sm:p-4 border border-grey-300">EMAIL</th>
            <th className="p-2 sm:p-4 border border-grey-300">APPROVE</th>
            <th className="p-2 sm:p-4 border border-grey-300">ACTION</th>
            <th className="p-2 sm:p-4 border border-grey-300">BAN PERIOD</th>
          </tr>
        </thead>
        <tbody>
          {candidates.map((candidate) => (
            <tr key={candidate.id}>
              <td className="p-2 sm:p-4 border border-grey-300">{candidate.name}</td>
              <td className="p-2 sm:p-4 border border-grey-300">{candidate.email}</td>
              <td className="p-2 sm:p-4 border border-grey-300">
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={candidate.approve}
                    onChange={() => handleToggleApproval(candidate.id)}
                    className="sr-only peer"
                  />
                  <div className="w-10 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-orange-300 rounded-full peer peer-checked:bg-orange-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all"></div>
                </label>
              </td>
              <td className="p-2 sm:p-4 border border-grey-300">
                <button
                  className="text-orange-700 underline"
                  onClick={() => handleViewProfile(candidate.profile)}
                >
                  View Profile
                </button>
              </td>
              <td className="p-2 sm:p-4 border border-grey-300">{candidate.banPeriod}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {selectedProfile && <ProfileModal profile={selectedProfile} onClose={handleCloseModal} />}
    </div>
  );
};

export default CandidateApproval;
